# Pingzy — Private Messaging, Done Right

**Pingzy** is a secure, end-to-end encrypted messaging app for Android. No phone number required — sign up with just your email.

## What Pingzy Does (Phase 1)

- **End-to-end encrypted text chat** — 1-on-1 and groups. Powered by NaCl `crypto_box` (X25519 + XSalsa20-Poly1305). Keys never leave your device; the server only sees encrypted blobs.
- **File sharing** — any file type, encrypted on your phone before upload.
- **Voice messages** — efficient Opus codec, built for low bandwidth.
- **Email OTP signup** — no phone number. Enter email → 6-digit code → pick a unique username.
- **Username search** — find people by username, add contacts, start chatting.
- **Works on weak internet** — messages queue offline and retry until delivered. Built for bad networks.
- **Minimal permissions** — the app asks only for what you approve (mic for voice, storage for files). No contacts access, no location, nothing sneaky.

## Our Thinking

Messaging is personal. Your conversations should belong to you — not to a company, not to advertisers, not to anyone who gets curious. Pingzy is built on a simple principle: **even with full access to our servers and source code, nobody can read your messages.** That's not a promise, it's mathematics.

## The Future (Phase 2+)

- **Voice & video calls** — end-to-end encrypted, WebRTC.
- **Desktop companion** — chat from your computer.
- **Disappearing messages** — auto-delete timers.
- **Stickers & reactions** — because chat should be fun too.

## Build

See [docs/BUILD.md](docs/BUILD.md) — or just check the Actions tab, the APK builds itself.
