# SecureChat ProGuard / R8 rules
# Obfuscate everything except what must stay intact for the app to run.

# Keep Android entry points
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends androidx.fragment.app.Fragment

# Room: keep entities/DAOs (accessed via reflection)
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao class *

# LazySodium / JNA: keep native bridge classes
-keep class com.goterl.lazysodium.** { *; }
-keep class com.sun.jna.** { *; }

# OkHttp: keep (uses reflection internally)
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Kotlin coroutines / metadata
-keep class kotlin.Metadata { *; }

# Strip all logging in release builds (no sensitive data in logs, ever)
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# Our own debug logger is stripped too (see util/Logger.kt)
-assumenosideeffects class com.securechat.app.util.Logger {
    public static *** d(...);
    public static *** v(...);
}
