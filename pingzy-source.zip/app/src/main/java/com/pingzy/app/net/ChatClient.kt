package com.pingzy.app.net

import com.pingzy.app.BuildConfig
import com.pingzy.app.crypto.CryptoManager
import com.pingzy.app.util.Logger
import kotlinx.coroutines.*
import okhttp3.*
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * WebSocket client: auth, send/recv, auto-reconnect with exponential backoff,
 * heartbeat. Server URL + cert pin come from BuildConfig (never hardcoded).
 */
class ChatClient(
    private val crypto: CryptoManager,
    private val scope: CoroutineScope
) {
    interface Listener {
        fun onMessage(msg: JSONObject)
        fun onConnectionChange(connected: Boolean)
    }

    var listener: Listener? = null
    private var ws: WebSocket? = null
    private var username: String? = null
    private var job: Job? = null
    private var backoffMs = 1000L
    // Single-flight RPC: requests are sequential, one waiter at a time.
    private var rpcWaiter: CompletableDeferred<JSONObject>? = null

    private fun buildClient(): OkHttpClient {
        val b = OkHttpClient.Builder()
            .pingInterval(25, TimeUnit.SECONDS)
            .connectTimeout(15, TimeUnit.SECONDS)
        // Certificate pinning (production). Empty pin = dev mode, log warning.
        val pin = BuildConfig.CERT_PIN
        if (pin.isNotBlank()) {
            val host = BuildConfig.SERVER_WS_URL
                .removePrefix("wss://").removePrefix("ws://")
                .substringBefore("/").substringBefore(":")
            b.certificatePinner(CertificatePinner.Builder()
                .add(host, pin).build())
        } else {
            Logger.w("ChatClient", "no cert pin configured (dev only)")
        }
        return b.build()
    }

    fun connect(username: String) {
        this.username = username
        job?.cancel()
        job = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    runSession(username)
                    backoffMs = 1000L
                } catch (e: Exception) {
                    Logger.w("ChatClient", "disconnected, retrying")
                }
                listener?.onConnectionChange(false)
                delay(backoffMs)
                backoffMs = minOf(backoffMs * 2, 60000L)
            }
        }
    }

    fun disconnect() { job?.cancel(); ws?.close(1000, null); ws = null }

    private suspend fun runSession(username: String) {
        val client = buildClient()
        val req = Request.Builder().url(BuildConfig.SERVER_WS_URL).build()
        val connected = CompletableDeferred<Unit>()
        val dead = CompletableDeferred<Unit>()  // completes when socket dies
        fun markDead() { if (!dead.isCompleted) dead.complete(Unit) }
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                listener?.onConnectionChange(true)
                connected.complete(Unit)
            }
            override fun onMessage(w: WebSocket, text: String) {
                scope.launch(Dispatchers.IO) { handle(JSONObject(text)) }
            }
            override fun onMessage(w: WebSocket, bytes: ByteString) {}
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
                if (!connected.isCompleted) connected.completeExceptionally(t)
                else markDead()
            }
            override fun onClosed(w: WebSocket, c: Int, r: String) {
                if (!connected.isCompleted)
                    connected.completeExceptionally(RuntimeException("closed"))
                else markDead()
            }
        })
        connected.await()
        // challenge/response auth with Ed25519 identity key
        val ch = rpc(JSONObject().put("type", "auth")
            .put("username", username), "challenge")
        val sig = crypto.signChallenge(CryptoManager.unb64(ch.getString("challenge")))
        rpc(JSONObject().put("type", "auth_response")
            .put("username", username)
            .put("signature", CryptoManager.b64(sig)), "authed")
        // Park here until the socket dies; then throw to trigger reconnect.
        dead.await()
        throw RuntimeException("socket died")
    }

    private suspend fun handle(m: JSONObject) {
        val w = rpcWaiter
        // Route "message" pushes to listener; everything else completes
        // the in-flight RPC (register/auth/send/... are sequential).
        if (m.optString("type") == "message") {
            listener?.onMessage(m)
        } else if (w != null) {
            rpcWaiter = null
            w.complete(m)
        }
        // Anything else with no waiter (e.g. stray sync_done) is dropped.
    }

    /** Request/response over the socket (one at a time). */
    suspend fun rpc(obj: JSONObject, expect: String): JSONObject {
        val w = ws ?: throw IllegalStateException("not connected")
        val d = CompletableDeferred<JSONObject>()
        rpcWaiter = d
        w.send(obj.toString())
        val resp = withTimeout(15000) { d.await() }
        if (resp.optString("type") == "error")
            throw RuntimeException("server: ${resp.optString("code")}: " +
                    resp.optString("message"))
        if (resp.optString("type") != expect)
            throw RuntimeException("unexpected reply: ${resp.optString("type")}")
        return resp
    }

    /** Pull queued messages (store-and-forward). Returns decrypted-ready frames. */
    suspend fun sync(): List<JSONObject> {
        val w = ws ?: throw IllegalStateException("not connected")
        val collected = mutableListOf<JSONObject>()
        val done = CompletableDeferred<Unit>()
        // Install a temporary collector: messages accumulate until sync_done.
        val prev = listener
        val collector = object : Listener {
            override fun onMessage(m: JSONObject) {
                if (m.optString("type") == "sync_done") done.complete(Unit)
                else collected.add(m)
            }
            override fun onConnectionChange(b: Boolean) {}
        }
        listener = collector
        try {
            w.send(JSONObject().put("type", "sync").toString())
            withTimeout(30000) { done.await() }
        } finally {
            listener = prev
        }
        return collected
    }

    fun sendRaw(obj: JSONObject) { ws?.send(obj.toString()) }
}
