package com.pingzy.app.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Least-privilege runtime permission helper.
 *
 * RULES (Jani's requirement):
 *  - Permissions are requested ONLY at first use of the feature, never
 *    at install or app start.
 *  - An in-app explanation dialog ALWAYS precedes the system dialog.
 *  - Denial degrades gracefully: the feature is unavailable but the
 *    rest of the app keeps working.
 */
object Permissions {

    const val REQ_AUDIO = 1001
    const val REQ_FILES = 1002
    const val REQ_CAMERA = 1003
    const val REQ_NOTIFY = 1004

    /** Permissions needed to attach a file (API-level aware). */
    fun filePermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    fun hasAll(context: Context, perms: Array<String>): Boolean =
        perms.all {
            ContextCompat.checkSelfPermission(context, it) ==
                    PackageManager.PERMISSION_GRANTED
        }

    /**
     * Show rationale, then request. [onResult] gets true if granted.
     * If the user previously denied with "don't ask again", we explain
     * that the feature needs Settings — but never block the app.
     */
    fun requestWithRationale(
        activity: Activity,
        perms: Array<String>,
        requestCode: Int,
        title: String,
        message: String,
        onResult: (granted: Boolean) -> Unit
    ) {
        if (hasAll(activity, perms)) {
            onResult(true)
            return
        }
        // Remember the callback for onRequestPermissionsResult
        pending[requestCode] = onResult
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Continue") { _, _ ->
                ActivityCompat.requestPermissions(activity, perms, requestCode)
            }
            .setNegativeButton("Not now") { _, _ ->
                pending.remove(requestCode)
                onResult(false)
            }
            .setCancelable(false)
            .show()
    }

    private val pending = mutableMapOf<Int, (Boolean) -> Unit>()

    /** Call from Activity.onRequestPermissionsResult. */
    fun onResult(requestCode: Int, grantResults: IntArray) {
        val cb = pending.remove(requestCode) ?: return
        cb(grantResults.isNotEmpty() &&
                grantResults.all { it == PackageManager.PERMISSION_GRANTED })
    }

    // ---- feature-specific helpers with built-in explanations ----

    fun ensureAudio(activity: Activity, onResult: (Boolean) -> Unit) {
        requestWithRationale(
            activity,
            arrayOf(Manifest.permission.RECORD_AUDIO),
            REQ_AUDIO,
            "Microphone access",
            "Pingzy needs microphone access to record voice messages. " +
                    "Recordings are encrypted on your phone before sending. " +
                    "You can still send text and files without it.",
            onResult
        )
    }

    fun ensureFiles(activity: Activity, onResult: (Boolean) -> Unit) {
        requestWithRationale(
            activity,
            filePermissions(),
            REQ_FILES,
            "File access",
            "Pingzy needs access to your media and files so you can " +
                    "share them. Files are encrypted on your phone before " +
                    "upload. You can still send text and voice messages " +
                    "without it.",
            onResult
        )
    }

    fun ensureCamera(activity: Activity, onResult: (Boolean) -> Unit) {
        requestWithRationale(
            activity,
            arrayOf(Manifest.permission.CAMERA),
            REQ_CAMERA,
            "Camera access",
            "Pingzy needs camera access so you can take a photo to " +
                    "share. The photo is encrypted on your phone before " +
                    "sending. You can still attach existing files without it.",
            onResult
        )
    }

    fun ensureNotifications(activity: Activity) {
        if (Build.VERSION.SDK_INT < 33) return
        if (hasAll(activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS))) return
        requestWithRationale(
            activity,
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            REQ_NOTIFY,
            "Notifications",
            "Allow notifications so you know when new encrypted messages " +
                    "arrive. The app works fully without them.",
            {}
        )
    }
}
