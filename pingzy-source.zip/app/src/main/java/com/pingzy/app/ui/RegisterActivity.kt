package com.pingzy.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.pingzy.app.R
import com.pingzy.app.PingzyApp
import com.pingzy.app.crypto.CryptoManager
import com.pingzy.app.util.Logger
import kotlinx.coroutines.*
import org.json.JSONObject

/**
 * Registration: email -> OTP -> username -> keygen -> done.
 * Private keys are generated ON DEVICE and never leave it.
 */
class RegisterActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var app: PingzyApp
    private lateinit var emailInput: EditText
    private lateinit var codeInput: EditText
    private lateinit var nameInput: EditText
    private lateinit var status: TextView
    private lateinit var btnEmail: Button
    private lateinit var btnCode: Button
    private lateinit var btnDone: Button
    private lateinit var codeRow: View
    private lateinit var nameRow: View
    private var email = ""
    private var verifyToken = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        app = application as PingzyApp
        if (app.session.loggedIn) { goChats(); return }
        setContentView(R.layout.activity_register)
        emailInput = findViewById(R.id.email_input)
        codeInput = findViewById(R.id.code_input)
        nameInput = findViewById(R.id.name_input)
        status = findViewById(R.id.status)
        btnEmail = findViewById(R.id.btn_send_code)
        btnCode = findViewById(R.id.btn_verify)
        btnDone = findViewById(R.id.btn_finish)
        codeRow = findViewById(R.id.code_row)
        nameRow = findViewById(R.id.name_row)

        btnEmail.setOnClickListener { requestCode() }
        btnCode.setOnClickListener { verifyCode() }
        btnDone.setOnClickListener { finishRegistration() }
    }

    private fun requestCode() {
        email = emailInput.text.toString().trim().lowercase()
        if (!email.contains("@")) { status("Enter a valid email"); return }
        status("Sending code...")
        scope.launch {
            try {
                if (withContext(Dispatchers.IO) { app.api.otpRequest(email) }) {
                    codeRow.visibility = View.VISIBLE
                    status("Code sent — check your email (10 min expiry)")
                } else status("Couldn't send code. Try again.")
            } catch (e: Exception) {
                Logger.w("Register", "otp request: ${e.message}")
                status("Network error. Try again.")
            }
        }
    }

    private fun verifyCode() {
        val code = codeInput.text.toString().trim()
        if (code.length != 6) { status("Enter the 6-digit code"); return }
        status("Verifying...")
        scope.launch {
            try {
                val t = withContext(Dispatchers.IO)
                    { app.api.otpVerify(email, code) }
                if (t != null) {
                    verifyToken = t
                    nameRow.visibility = View.VISIBLE
                    status("Email verified! Pick a username (3-20 chars).")
                } else status("Wrong or expired code. Try again.")
            } catch (e: Exception) {
                status("Network error. Try again.")
            }
        }
    }

    private fun finishRegistration() {
        val name = nameInput.text.toString().trim()
        if (!name.matches(Regex("[A-Za-z0-9_]{3,20}"))) {
            status("Username: 3-20 chars, letters/numbers/underscore"); return
        }
        status("Creating account...")
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    // 1. Generate keys ON DEVICE (never leave the phone)
                    app.crypto.generateKeys()
                    // 2. Register: server stores pubkeys + username only
                    rawRegister(name, email, verifyToken)
                    app.session.username = name
                }
                goChats()
            } catch (e: Exception) {
                Logger.w("Register", "finish: ${e.message}")
                status("Failed: ${e.message}")
            }
        }
    }

    private fun status(s: String) { status.text = s }

    private fun goChats() {
        startActivity(Intent(this, ChatListActivity::class.java))
        finish()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    /** One-shot registration socket (no auto-reconnect needed). */
    private suspend fun rawRegister(name: String, email: String,
                                    token: String) =
        withContext(Dispatchers.IO) {
            val latch = CompletableDeferred<JSONObject>()
            val http = okhttp3.OkHttpClient()
            val ws = http.newWebSocket(
                okhttp3.Request.Builder()
                    .url(com.pingzy.app.BuildConfig.SERVER_WS_URL)
                    .build(),
                object : okhttp3.WebSocketListener() {
                    override fun onMessage(w: okhttp3.WebSocket,
                                           text: String) {
                        latch.complete(JSONObject(text))
                    }
                })
            val crypto = app.crypto
            ws.send(JSONObject()
                .put("type", "register")
                .put("username", name)
                .put("email", email)
                .put("verification_token", token)
                .put("identity_pubkey",
                    CryptoManager.b64(crypto.identityPublicKey()))
                .put("box_pubkey",
                    CryptoManager.b64(crypto.boxPublicKey()))
                .toString())
            val r = withTimeout(15000) { latch.await() }
            ws.close(1000, null)
            if (r.optString("type") == "error")
                throw RuntimeException(r.optString("message", "register failed"))
        }
}
