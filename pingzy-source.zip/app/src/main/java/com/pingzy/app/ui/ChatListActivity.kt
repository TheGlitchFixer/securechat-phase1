package com.pingzy.app.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pingzy.app.R
import com.pingzy.app.PingzyApp
import com.pingzy.app.net.ChatService
import com.pingzy.app.util.Logger
import com.pingzy.app.util.Permissions
import kotlinx.coroutines.*

data class ChatRow(val chatId: String, val title: String,
                   val preview: String, val ts: Long, val isGroup: Boolean)

/**
 * Home screen: list of chats, connection indicator, pending-count badge.
 * Connects the WebSocket on start (auto-reconnect handled by ChatClient).
 */
class ChatListActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var app: PingzyApp
    private lateinit var list: ListView
    private lateinit var statusDot: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private val rows = mutableListOf<ChatRow>()
    private val titles = mutableListOf<String>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        app = application as PingzyApp
        if (!app.session.loggedIn) {
            startActivity(Intent(this, RegisterActivity::class.java))
            finish(); return
        }
        setContentView(R.layout.activity_chat_list)
        list = findViewById(R.id.chat_list)
        statusDot = findViewById(R.id.status_dot)
        adapter = ArrayAdapter(this,
            android.R.layout.simple_list_item_2, android.R.id.text1, titles)
        list.adapter = adapter

        findViewById<Button>(R.id.btn_contacts).setOnClickListener {
            startActivity(Intent(this, ContactsActivity::class.java)) }
        findViewById<Button>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java)) }

        list.setOnItemClickListener { _, _, pos, _ ->
            val row = rows[pos]
            val i = Intent(this, ChatActivity::class.java)
                .putExtra("chatId", row.chatId)
                .putExtra("title", row.title)
            startActivity(i)
        }

        app.inbox.onConnected = { c -> runOnUiThread {
            statusDot.text = if (c) "● online" else "○ offline"
        } }
        app.inbox.onNewMessage = { refresh() }
        // Foreground service keeps the connection alive on poor networks
        // and aggressive battery savers (see net/ChatService.kt).
        val svc = Intent(this, ChatService::class.java)
            .setAction(ChatService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) {
            ContextCompat.startForegroundService(this, svc)
        } else {
            startService(svc)
        }
        Permissions.ensureNotifications(this)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        scope.launch {
            try {
                val msgs = withContext(Dispatchers.IO) {
                    // latest message per chat
                    val ids = app.db.messages().chatIds()
                    ids.mapNotNull { id ->
                        val m = app.db.messages().forChat(id).lastOrNull()
                            ?: return@mapNotNull null
                        val title = if (id.startsWith("group:"))
                            app.db.groups()
                                .get(id.removePrefix("group:").toLong())
                                ?.name ?: "Group"
                        else id
                        val prev = try {
                            org.json.JSONObject(
                                org.json.JSONObject(m.body)
                                    .optString("body", ""))
                                .optString("body", m.msgType)
                        } catch (_: Exception) { m.msgType }
                        val label = when (m.msgType) {
                            "text" -> prev.take(60)
                            "voice" -> "🎤 voice message"
                            else -> "📎 file"
                        }
                        ChatRow(id, title,
                            (if (m.outgoing) "You: " else "${m.sender}: ") + label,
                            m.ts, id.startsWith("group:"))
                    }.sortedByDescending { it.ts }
                }
                rows.clear(); rows.addAll(msgs)
                titles.clear()
                titles.addAll(msgs.map { "${it.title}\n${it.preview}" })
                adapter.notifyDataSetChanged()
            } catch (e: Exception) {
                Logger.w("ChatList", "refresh: ${e.message}")
            }
        }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<String>,
                                            res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        Permissions.onResult(rc, res)
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
