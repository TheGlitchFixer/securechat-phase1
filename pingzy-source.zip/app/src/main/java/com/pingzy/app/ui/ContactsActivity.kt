package com.pingzy.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.pingzy.app.R
import com.pingzy.app.PingzyApp
import com.pingzy.app.crypto.CryptoManager
import com.pingzy.app.data.ContactEntity
import com.pingzy.app.data.GroupEntity
import com.pingzy.app.util.Logger
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject

/**
 * Contacts: add by exact username (looked up server-side — never uploads
 * your address book). Groups: pick members, admin auto-distributes the
 * group key via E2E DMs; key rotates when members are removed.
 */
class ContactsActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var app: PingzyApp
    private lateinit var adapter: ArrayAdapter<String>
    private val names = mutableListOf<String>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        app = application as PingzyApp
        setContentView(R.layout.activity_contacts)
        title = "Contacts"
        adapter = ArrayAdapter(this,
            android.R.layout.simple_list_item_1, names)
        findViewById<ListView>(R.id.contact_list).adapter = adapter
        findViewById<ListView>(R.id.contact_list).setOnItemClickListener { _,_,p,_ ->
            startActivity(Intent(this, ChatActivity::class.java)
                .putExtra("chatId", names[p]).putExtra("title", names[p]))
        }
        findViewById<Button>(R.id.btn_add).setOnClickListener { addContact() }
        findViewById<Button>(R.id.btn_group).setOnClickListener { createGroup() }
        refresh()
    }

    private fun refresh() {
        scope.launch {
            names.clear()
            names.addAll(withContext(Dispatchers.IO) {
                app.db.contacts().all().map { it.username } })
            adapter.notifyDataSetChanged()
        }
    }

    private fun addContact() {
        val input = EditText(this).apply { hint = "username" }
        AlertDialog.Builder(this).setTitle("Add contact")
            .setMessage("Enter their exact Pingzy username.")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                lookupAndAdd(input.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun lookupAndAdd(username: String) {
        if (!username.matches(Regex("[A-Za-z0-9_]{3,20}"))) {
            toast("Invalid username"); return
        }
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) {
                    app.chatClient.rpc(JSONObject().put("type", "list_users"),
                        "user_list") }
                val found = r.getJSONArray("users").let { arr ->
                    (0 until arr.length()).map { arr.getJSONObject(it) }
                        .find { it.getString("username") == username } }
                if (found == null) { toast("User not found"); return@launch }
                withContext(Dispatchers.IO) {
                    app.db.contacts().upsert(ContactEntity(username,
                        found.getString("box_pubkey"))) }
                toast("Added $username"); refresh()
            } catch (e: Exception) {
                Logger.w("Contacts", "add: ${e.message}")
                toast("Couldn't add contact")
            }
        }
    }

    private fun createGroup() {
        scope.launch {
            val all = withContext(Dispatchers.IO) {
                app.db.contacts().all() }
            if (all.isEmpty()) { toast("Add contacts first"); return@launch }
            val checked = BooleanArray(all.size)
            AlertDialog.Builder(this@ContactsActivity)
                .setTitle("New group — pick members")
                .setMultiChoiceItems(
                    all.map { it.username }.toTypedArray(), null) { _, w, c ->
                    checked[w] = c }
                .setPositiveButton("Create") { _, _ ->
                    val members = all.filterIndexed { i, _ -> checked[i] }
                    if (members.isNotEmpty()) makeGroup(members.map {
                        it.username to it.boxPubKeyB64 })
                }.setNegativeButton("Cancel", null).show()
        }
    }

    private fun makeGroup(members: List<Pair<String, String>>) {
        scope.launch {
            try {
                val nameIn = EditText(this@ContactsActivity)
                    .apply { hint = "Group name" }
                AlertDialog.Builder(this@ContactsActivity)
                    .setTitle("Group name").setView(nameIn)
                    .setPositiveButton("Create") { _, _ ->
                        scope.launch { doMakeGroup(
                            nameIn.text.toString().ifBlank { "Group" },
                            members) } }
                    .setNegativeButton("Cancel", null).show()
            } catch (e: Exception) { toast("Couldn't create group") }
        }
    }

    private suspend fun doMakeGroup(name: String,
                                    members: List<Pair<String, String>>) =
        withContext(Dispatchers.IO) {
            val crypto = app.crypto
            // 1. create group on server
            val r = app.chatClient.rpc(JSONObject()
                .put("type", "group_create").put("name", name)
                .put("members", JSONArray(members.map { it.first })),
                "group_created")
            val gid = r.getLong("group_id")
            // 2. generate group key + distribute via E2E DM to each member
            val gk = crypto.randomKey()
            app.db.groups().upsert(GroupEntity(gid, name,
                JSONArray(members.map { it.first } +
                        listOf(app.session.username!!)).toString(),
                CryptoManager.b64(gk)))
            for ((u, pubB64) in members) {
                val env = JSONObject().put("v", 1).put("kind", "group_key")
                    .put("group_id", gid)
                    .put("group_key", CryptoManager.b64(gk)).toString()
                    .toByteArray()
                val s = crypto.boxEncrypt(CryptoManager.unb64(pubB64), env)
                app.chatClient.rpc(JSONObject().put("type", "send")
                    .put("to", u).put("nonce", s.nonceB64)
                    .put("ciphertext", s.cipherB64).put("msg_type", "text"),
                    "sent")
            }
            withContext(Dispatchers.Main) {
                toast("Group created")
                startActivity(Intent(this@ContactsActivity,
                    ChatActivity::class.java)
                    .putExtra("chatId", "group:$gid").putExtra("title", name))
            }
        }

    private fun toast(s: String) =
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
