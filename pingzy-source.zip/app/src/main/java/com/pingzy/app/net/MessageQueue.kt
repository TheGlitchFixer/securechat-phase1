package com.pingzy.app.net

import com.pingzy.app.data.AppDatabase
import com.pingzy.app.data.OutboxEntity
import com.pingzy.app.util.Logger
import kotlinx.coroutines.*
import org.json.JSONObject

/**
 * LOW-BANDWIDTH: local outbox with FIFO ordering + exponential backoff.
 * Messages are NEVER lost on network drop — they stay queued until the
 * server acks them. Payloads are already E2E-encrypted before queueing.
 */
class MessageQueue(
    private val db: AppDatabase,
    private val client: ChatClient,
    private val scope: CoroutineScope
) {
    private var pumpJob: Job? = null

    fun enqueue(chatId: String, kind: String, recipient: String,
                nonceB64: String, cipherB64: String, msgType: String) {
        scope.launch(Dispatchers.IO) {
            db.outbox().insert(OutboxEntity(
                chatId = chatId, kind = kind, recipient = recipient,
                nonceB64 = nonceB64, cipherB64 = cipherB64, msgType = msgType))
            Logger.d("MessageQueue", "queued for $chatId")
            pump()
        }
    }

    /** Call on reconnect / after enqueue. Sends all due messages. */
    fun pump() {
        if (pumpJob?.isActive == true) return
        pumpJob = scope.launch(Dispatchers.IO) {
            while (true) {
                val due = db.outbox().due(System.currentTimeMillis())
                if (due.isEmpty()) break
                var sentAny = false
                for (o in due) {
                    try {
                        val req = if (o.kind == "dm") {
                            JSONObject().put("type", "send")
                                .put("to", o.recipient)
                        } else {
                            JSONObject().put("type", "group_send")
                                .put("group_id", o.recipient.toLong())
                        }.put("nonce", o.nonceB64)
                            .put("ciphertext", o.cipherB64)
                            .put("msg_type", o.msgType)
                        client.rpc(req, "sent")
                        db.outbox().remove(o.id)
                        sentAny = true
                    } catch (e: Exception) {
                        // exponential backoff: 5s, 20s, 80s, ... max 10 min
                        val next = minOf(600_000L,
                            5000L * (1L shl minOf(o.attempts, 8)))
                        db.outbox().reschedule(o.id, o.attempts + 1,
                            System.currentTimeMillis() + next)
                        Logger.w("MessageQueue",
                            "send failed, retry in ${next / 1000}s")
                        break
                    }
                }
                if (!sentAny) break
            }
        }
    }

    suspend fun pendingCount(): Int = db.outbox().count()
}
