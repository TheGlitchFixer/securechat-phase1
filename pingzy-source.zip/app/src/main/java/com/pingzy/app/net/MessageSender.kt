package com.pingzy.app.net

import com.pingzy.app.PingzyApp
import com.pingzy.app.crypto.CryptoManager
import com.pingzy.app.data.MessageEntity
import com.pingzy.app.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/**
 * Outgoing pipeline. Every payload is E2E-encrypted BEFORE it touches the
 * network or the outbox queue:
 *   text  -> crypto_box (dm) or secretbox w/ group key (group)
 *   file/voice -> random file key + secretbox(file bytes); the file key
 *                 travels inside the E2E text envelope; the blob goes to
 *                 /files (server sees ciphertext only).
 */
class MessageSender(private val app: PingzyApp) {

    private val crypto: CryptoManager get() = app.crypto

    /** Envelope v1: {"v":1,"kind":...,"body":...} */
    private fun envelope(kind: String, body: Any): ByteArray =
        JSONObject().put("v", 1).put("kind", kind).put("body", body)
            .toString().toByteArray()

    suspend fun sendText(chatId: String, text: String) {
        val sealed = if (chatId.startsWith("group:")) {
            val g = app.db.groups().get(chatId.removePrefix("group:").toLong())
                ?: throw RuntimeException("unknown group")
            crypto.secretEncrypt(CryptoManager.unb64(g.groupKeyB64),
                envelope("text", text))
        } else {
            val c = app.db.contacts().get(chatId)
                ?: throw RuntimeException("unknown contact")
            crypto.boxEncrypt(CryptoManager.unb64(c.boxPubKeyB64),
                envelope("text", text))
        }
        val kind = if (chatId.startsWith("group:")) "group" else "dm"
        val recipient = if (kind == "dm") chatId
                        else chatId.removePrefix("group:")
        app.queue.enqueue(chatId, kind, recipient,
            sealed.nonceB64, sealed.cipherB64, "text")
        // store outgoing copy locally for instant UI
        app.db.messages().insert(MessageEntity(
            msgId = -(System.currentTimeMillis()), // temp id; server id on ack
            chatId = chatId, kind = kind, sender = app.session.username!!,
            msgType = "text",
            body = JSONObject().put("v", 1).put("kind", "text")
                .put("body", text).toString(),
            ts = System.currentTimeMillis(), outgoing = true))
        app.queue.pump()
    }

    /**
     * Encrypt [plainFile], upload the blob, then send the file key inside
     * an E2E envelope. Returns upload progress via [onProgress].
     */
    suspend fun sendFile(chatId: String, plainFile: File, mime: String,
                         kind: String, // "file" | "voice"
                         uploadToken: suspend () -> String,
                         onProgress: (Int) -> Unit = {}
    ) = withContext(Dispatchers.IO) {
        // 1. E2E-encrypt the file bytes with a fresh random key
        val fileKey = crypto.randomKey()
        val bytes = plainFile.readBytes()
        val sealed = crypto.secretEncrypt(fileKey, bytes)
        val blob = File.createTempFile("up", ".bin",
            app.cacheDir).apply {
            writeBytes(CryptoManager.unb64(sealed.cipherB64))
        }
        try {
            // 2. Upload ciphertext blob (server can't read it)
            val up = app.api.uploadFile(blob, plainFile.name, mime,
                uploadToken(), onProgress)
            // 3. Send file key + metadata inside E2E envelope
            val meta = JSONObject()
                .put("file_id", up.fileId)
                .put("file_key", CryptoManager.b64(fileKey))
                .put("file_nonce", sealed.nonceB64)
                .put("filename", plainFile.name)
                .put("mime", mime)
                .put("size", bytes.size)
            val env = if (chatId.startsWith("group:")) {
                val g = app.db.groups()
                    .get(chatId.removePrefix("group:").toLong())!!
                crypto.secretEncrypt(CryptoManager.unb64(g.groupKeyB64),
                    envelope(kind, meta))
            } else {
                val c = app.db.contacts().get(chatId)!!
                crypto.boxEncrypt(CryptoManager.unb64(c.boxPubKeyB64),
                    envelope(kind, meta))
            }
            val k = if (chatId.startsWith("group:")) "group" else "dm"
            val rcpt = if (k == "dm") chatId else chatId.removePrefix("group:")
            app.queue.enqueue(chatId, k, rcpt,
                env.nonceB64, env.cipherB64, kind)
            app.db.messages().insert(MessageEntity(
                msgId = -(System.currentTimeMillis()), chatId = chatId,
                kind = k, sender = app.session.username!!, msgType = kind,
                body = JSONObject().put("v", 1).put("kind", kind)
                    .put("body", meta).put("local_path", plainFile.absolutePath)
                    .toString(),
                ts = System.currentTimeMillis(), outgoing = true))
            app.queue.pump()
        } finally {
            blob.delete()
        }
        Logger.i("MessageSender", "file queued ($kind)")
    }

    /** Download + decrypt an incoming file/voice message to [dest]. */
    suspend fun fetchAttachment(msg: MessageEntity, dest: File,
                                onProgress: (Int) -> Unit = {}
    ) = withContext(Dispatchers.IO) {
        val body = JSONObject(JSONObject(msg.body).getString("body"))
        val meta = if (body.has("file_id")) body
                   else JSONObject(body.getString("body"))
        val tmp = File.createTempFile("dl", ".bin", app.cacheDir)
        try {
            app.api.downloadFile(meta.getString("file_id"), tmp, onProgress)
            dest.writeBytes(crypto.secretDecryptRaw(
                CryptoManager.unb64(meta.getString("file_key")),
                CryptoManager.unb64(meta.getString("file_nonce")),
                tmp.readBytes()))
        } finally {
            tmp.delete()
        }
    }
}
