package com.pingzy.app.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.pingzy.app.R
import com.pingzy.app.PingzyApp
import com.pingzy.app.media.VoicePlayer
import com.pingzy.app.media.VoiceRecorder
import com.pingzy.app.net.MessageSender
import com.pingzy.app.util.Logger
import com.pingzy.app.util.Permissions
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File

/**
 * 1-on-1 and group chat screen.
 *  - Text: E2E encrypted, queued offline with retry (MessageQueue).
 *  - Files: picked via system picker (runtime permission w/ rationale),
 *    encrypted on-device, uploaded with progress.
 *  - Voice: hold-to-record (runtime mic permission w/ rationale),
 *    Opus@12kbps (API 26+) or AAC fallback, encrypted like a file.
 * Denying any permission degrades gracefully — text always works.
 */
class ChatActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var app: PingzyApp
    private lateinit var sender: MessageSender
    private lateinit var chatId: String
    private lateinit var list: ListView
    private lateinit var input: EditText
    private lateinit var adapter: ArrayAdapter<String>
    private val lines = mutableListOf<String>()
    private val msgIds = mutableListOf<Long>()  // parallel to lines
    private val recorder = VoiceRecorder()
    private val player = VoicePlayer()
    private var uploadToken: String? = null

    companion object {
        const val REQ_PICK_FILE = 2001
        const val REQ_TAKE_PHOTO = 2002
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        app = application as PingzyApp
        sender = MessageSender(app)
        chatId = intent.getStringExtra("chatId")!!
        title = intent.getStringExtra("title") ?: chatId
        setContentView(R.layout.activity_chat)
        list = findViewById(R.id.msg_list)
        input = findViewById(R.id.msg_input)
        adapter = ArrayAdapter(this,
            android.R.layout.simple_list_item_1, lines)
        list.adapter = adapter

        findViewById<Button>(R.id.btn_send).setOnClickListener { sendText() }
        findViewById<Button>(R.id.btn_attach).setOnClickListener { pickFile() }
        findViewById<Button>(R.id.btn_camera).setOnClickListener { takePhoto() }

        // Hold-to-record voice button
        findViewById<Button>(R.id.btn_voice).setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> startRecording()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    stopRecording()
            }
            true
        }

        list.setOnItemClickListener { _, _, pos, _ -> playVoice(pos) }
        app.inbox.onNewMessage = { id ->
            if (id == chatId) runOnUiThread { load() } }
        load()
        fetchUploadToken()
    }

    // ---------------- text ----------------
    private fun sendText() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        scope.launch {
            try { sender.sendText(chatId, t); load() }
            catch (e: Exception) {
                Logger.w("Chat", "send: ${e.message}")
                toast("Couldn't send — queued for retry")
                load()
            }
        }
    }

    // ---------------- files ----------------
    private fun pickFile() {
        Permissions.ensureFiles(this) { granted ->
            if (!granted) { toast("File access denied — text still works"); return@ensureFiles }
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT)
                .apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) },
                REQ_PICK_FILE)
        }
    }

    private fun takePhoto() {
        Permissions.ensureCamera(this) { granted ->
            if (!granted) { toast("Camera denied"); return@ensureCamera }
            // Minimal: use system camera via GET_CONTENT fallback.
            // (FileProvider capture is Phase-2 polish.)
            pickFile()
        }
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == REQ_PICK_FILE && res == Activity.RESULT_OK) {
            data?.data?.let { shareUri(it) }
        }
    }

    private fun shareUri(uri: Uri) {
        scope.launch {
            try {
                val name = queryName(uri) ?: "file_${System.currentTimeMillis()}"
                val mime = contentResolver.getType(uri)
                    ?: "application/octet-stream"
                val tmp = File.createTempFile("share", ".bin", cacheDir)
                contentResolver.openInputStream(uri)?.use { ins ->
                    tmp.outputStream().use { ins.copyTo(it) } }
                // LOW-BANDWIDTH: downscale images before encrypt+upload
                val small = maybeCompressImage(tmp, mime)
                sender.sendFile(chatId, small, mime, "file",
                    uploadToken = { getToken() }) { p ->
                    runOnUiThread { title = "Uploading $p%" } }
                title = intent.getStringExtra("title") ?: chatId
                tmp.delete(); if (small != tmp) small.delete()
                load()
            } catch (e: Exception) {
                Logger.w("Chat", "share: ${e.message}")
                toast("Couldn't share file")
            }
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i)
            }
        }
        return null
    }

    /** Downscale JPEG/PNG over ~1.5MB to max 1600px (bandwidth saver). */
    private fun maybeCompressImage(f: File, mime: String): File {
        if (!mime.startsWith("image/") || f.length() < 1_500_000) return f
        return try {
            val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath)
                ?: return f
            val scale = 1600f / maxOf(bmp.width, bmp.height).coerceAtLeast(1)
            if (scale >= 1f) return f
            val small = android.graphics.Bitmap.createScaledBitmap(bmp,
                (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            val out = File.createTempFile("img", ".jpg", cacheDir)
            out.outputStream().use {
                small.compress(android.graphics.Bitmap.CompressFormat.JPEG,
                    80, it) }
            bmp.recycle(); small.recycle()
            Logger.i("Chat", "image ${f.length()} -> ${out.length()}")
            out
        } catch (e: Exception) { f }
    }

    // ---------------- voice ----------------
    private fun startRecording() {
        Permissions.ensureAudio(this) { granted ->
            if (!granted) {
                toast("Mic denied — text still works"); return@ensureAudio
            }
            try {
                recorder.start(this@ChatActivity)
                toast("Recording... release to send")
            } catch (e: Exception) { toast("Couldn't record") }
        }
    }

    private fun stopRecording() {
        val f = recorder.stop() ?: return
        scope.launch {
            try {
                sender.sendFile(chatId, f,
                    if (recorder.isOpus) "audio/opus" else "audio/mp4",
                    "voice", uploadToken = { getToken() })
                f.delete()
                load()
            } catch (e: Exception) {
                Logger.w("Chat", "voice: ${e.message}")
                toast("Couldn't send voice message")
            }
        }
    }

    private fun playVoice(pos: Int) {
        scope.launch(Dispatchers.IO) {
            try {
                val id = msgIds.getOrNull(pos) ?: return@launch
                val m = app.db.messages().forChat(chatId)
                    .find { it.msgId == id } ?: return@launch
                if (m.msgType != "voice") return@launch
                val dest = File(cacheDir,
                    "play_${id}.${if (recorder.isOpus) "opus" else "m4a"}")
                sender.fetchAttachment(m, dest)
                withContext(Dispatchers.Main) {
                    player.onDone = { toast("Done") }
                    player.play(dest)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { toast("Couldn't play") }
            }
        }
    }

    // ---------------- list ----------------
    private fun load() {
        scope.launch {
            val items = withContext(Dispatchers.IO) {
                app.db.messages().forChat(chatId).map { m ->
                    val body = try {
                        JSONObject(JSONObject(m.body).optString("body", ""))
                    } catch (_: Exception) { JSONObject() }
                    val who = if (m.outgoing) "You" else m.sender
                    val text = when (m.msgType) {
                        "text" -> body.optString("body", "")
                        "voice" -> "🎤 voice — tap to play"
                        else -> "📎 ${body.optString("filename", "file")} — tap to download"
                    }
                    Pair(m.msgId, "$who: $text")
                }
            }
            msgIds.clear(); msgIds.addAll(items.map { it.first })
            lines.clear(); lines.addAll(items.map { it.second })
            adapter.notifyDataSetChanged()
            list.setSelection(lines.size - 1)
        }
    }

    private suspend fun getToken(): String {
        uploadToken?.let { return it }
        // fresh token requires re-auth rpc; ChatClient holds one per session.
        // Simplest correct: ask server for a new one via re-auth.
        val c = app.chatClient
        val ch = c.rpc(org.json.JSONObject().put("type", "auth")
            .put("username", app.session.username!!), "challenge")
        val sig = app.crypto.signChallenge(
            com.pingzy.app.crypto.CryptoManager.unb64(
                ch.getString("challenge")))
        val r = c.rpc(org.json.JSONObject().put("type", "auth_response")
            .put("username", app.session.username!!)
            .put("signature", com.pingzy.app.crypto.CryptoManager.b64(sig)),
            "authed")
        return r.getString("upload_token").also { uploadToken = it }
    }

    private fun fetchUploadToken() {
        scope.launch(Dispatchers.IO) {
            try { getToken() } catch (_: Exception) {}
        }
    }

    private fun toast(s: String) =
        runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    override fun onRequestPermissionsResult(rc: Int, p: Array<String>,
                                            r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        Permissions.onResult(rc, r)
    }

    override fun onDestroy() {
        player.stop()
        scope.cancel(); super.onDestroy()
    }
}
