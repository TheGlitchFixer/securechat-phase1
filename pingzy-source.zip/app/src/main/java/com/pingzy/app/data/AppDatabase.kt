package com.pingzy.app.data

import android.content.Context
import androidx.room.*

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(m: MessageEntity)
    @Query("SELECT * FROM messages WHERE chatId=:c ORDER BY ts ASC")
    suspend fun forChat(c: String): List<MessageEntity>
    @Query("SELECT DISTINCT chatId FROM messages ORDER BY ts DESC")
    suspend fun chatIds(): List<String>
}

@Dao
interface OutboxDao {
    @Insert suspend fun insert(o: OutboxEntity): Long
    @Query("SELECT * FROM outbox WHERE nextTryAt<=:now ORDER BY id ASC LIMIT 20")
    suspend fun due(now: Long): List<OutboxEntity>
    @Query("UPDATE outbox SET attempts=:a, nextTryAt=:n WHERE id=:id")
    suspend fun reschedule(id: Long, a: Int, n: Long)
    @Query("DELETE FROM outbox WHERE id=:id")
    suspend fun remove(id: Long)
    @Query("SELECT COUNT(*) FROM outbox")
    suspend fun count(): Int
}

@Dao
interface ContactDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: ContactEntity)
    @Query("SELECT * FROM contacts ORDER BY username")
    suspend fun all(): List<ContactEntity>
    @Query("SELECT * FROM contacts WHERE username=:u LIMIT 1")
    suspend fun get(u: String): ContactEntity?
    @Query("DELETE FROM contacts WHERE username=:u")
    suspend fun delete(u: String)
}

@Dao
interface GroupDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(g: GroupEntity)
    @Query("SELECT * FROM groups ORDER BY name")
    suspend fun all(): List<GroupEntity>
    @Query("SELECT * FROM groups WHERE groupId=:id LIMIT 1")
    suspend fun get(id: Long): GroupEntity?
}

@Database(entities = [MessageEntity::class, OutboxEntity::class,
    ContactEntity::class, GroupEntity::class], version = 1,
    exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun outbox(): OutboxDao
    abstract fun contacts(): ContactDao
    abstract fun groups(): GroupDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext,
                AppDatabase::class.java, "pingzy.db").build()
                .also { inst = it }
        }
    }
}
