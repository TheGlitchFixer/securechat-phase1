package com.pingzy.app.net

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.pingzy.app.PingzyApp
import com.pingzy.app.util.Logger

/**
 * Foreground service that keeps the Pingzy connection alive.
 *
 * Why: on poor networks and aggressive OEM battery savers, a background
 * app's WebSocket gets killed — messages then only arrive on next app
 * open. A foreground service with a persistent (low-priority)
 * notification tells Android "the user knows I'm running", which
 * dramatically reduces kills and keeps the offline queue pumping.
 *
 * The actual networking lives in ChatClient (app-scoped); this service
 * just holds a foreground slot and restarts the connection if needed.
 * No message content ever touches this class.
 */
class ChatService : Service() {

    companion object {
        const val CHANNEL_ID = "pingzy_conn"
        const val NOTIF_ID = 1
        const val ACTION_START = "com.pingzy.app.START_CONN"
        const val ACTION_STOP = "com.pingzy.app.STOP_CONN"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int,
                               startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                (application as PingzyApp).chatClient.disconnect()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIF_ID, buildNotification())
                val app = application as PingzyApp
                val user = app.session.username
                if (user != null) {
                    // ChatClient.connect is idempotent (cancels prior job).
                    app.chatClient.connect(user)
                    Logger.i("ChatService", "foreground connection started")
                } else {
                    Logger.w("ChatService", "no logged-in user; stopping")
                    stopSelf()
                }
                // If the process is killed, restart the service.
                return START_STICKY
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val mgr = getSystemService(NotificationManager::class.java)
            mgr.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "Connection",
                NotificationManager.IMPORTANCE_MIN).apply {
                description = "Keeps Pingzy connected for message delivery"
                setShowBadge(false)
            })
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pingzy")
            .setContentText("Listening for encrypted messages")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
}
