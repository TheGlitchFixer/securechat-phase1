package com.pingzy.app.crypto

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.goterl.lazysodium.LazySodiumAndroid
import com.goterl.lazysodium.SodiumAndroid
import com.goterl.lazysodium.interfaces.Box
import com.goterl.lazysodium.interfaces.SecretBox
import com.goterl.lazysodium.interfaces.Sign
import com.goterl.lazysodium.utils.Key
import com.goterl.lazysodium.utils.KeyPair
import com.pingzy.app.util.Logger
import java.security.SecureRandom

/**
 * All end-to-end cryptography for Pingzy.
 *
 * Primitives (libsodium / NaCl — audited, standard):
 *   Identity:  Ed25519 signing keypair  (proves "I am alice" to the server)
 *   Encryption: X25519 + XSalsa20-Poly1305 (crypto_box) for 1-on-1 messages
 *   Groups:    XSalsa20-Poly1305 (crypto_secretbox) with a shared group key
 *   Files:     XSalsa20-Poly1305 (crypto_secretbox) with a per-file key
 *
 * KERCKHOFFS'S PRINCIPLE: security rests ONLY on the secrecy of the
 * private keys. The protocol, this source code, and the server may all be
 * public — without a private key, messages are unreadable.
 *
 * Private keys are stored in EncryptedSharedPreferences (backed by the
 * Android Keystore) and NEVER leave the device, NEVER go to the server.
 * The server only ever sees public keys + opaque ciphertext blobs.
 *
 * No plaintext, keys, or nonces are ever logged (see Logger + R8 rules).
 */
class CryptoManager private constructor(context: Context) {

    private val sodium = LazySodiumAndroid(SodiumAndroid())
    private val random = SecureRandom()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context.applicationContext,
        "pingzy_keys",
        MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    companion object {
        private const val PREF_IDENTITY_PRIV = "identity_priv"   // ed25519 seed
        private const val PREF_IDENTITY_PUB = "identity_pub"     // ed25519 pub
        private const val PREF_BOX_PRIV = "box_priv"             // x25519 priv
        private const val PREF_BOX_PUB = "box_pub"               // x25519 pub

        @Volatile private var instance: CryptoManager? = null
        fun get(context: Context): CryptoManager =
            instance ?: synchronized(this) {
                instance ?: CryptoManager(context).also { instance = it }
            }

        fun b64(bytes: ByteArray): String =
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        fun unb64(s: String): ByteArray = Base64.decode(s, Base64.DEFAULT)
    }

    // ------------------------------------------------------------------
    // Key management
    // ------------------------------------------------------------------

    fun hasKeys(): Boolean =
        prefs.contains(PREF_IDENTITY_PRIV) && prefs.contains(PREF_BOX_PRIV) &&
        prefs.contains(PREF_IDENTITY_PUB) && prefs.contains(PREF_BOX_PUB)

    /** Generate fresh identity + encryption keypairs. Called once at registration. */
    fun generateKeys() {
        // Ed25519 identity keypair
        val signKp = KeyPair(
            Key.fromBytes(ByteArray(Sign.ED25519_SECRETKEYBYTES)),
            Key.fromBytes(ByteArray(Sign.ED25519_PUBLICKEYBYTES))
        )
        check(sodium.cryptoSignKeypair(signKp.publicKey.asBytes,
                                       signKp.secretKey.asBytes)) {
            "keygen failed"
        }
        // X25519 box keypair
        val boxKp = KeyPair(
            Key.fromBytes(ByteArray(Box.PUBLICKEYBYTES)),
            Key.fromBytes(ByteArray(Box.SECRETKEYBYTES))
        )
        check(sodium.cryptoBoxKeypair(boxKp.publicKey.asBytes,
                                      boxKp.secretKey.asBytes)) {
            "keygen failed"
        }
        prefs.edit()
            .putString(PREF_IDENTITY_PRIV, b64(signKp.secretKey.asBytes))
            .putString(PREF_IDENTITY_PUB, b64(signKp.publicKey.asBytes))
            .putString(PREF_BOX_PRIV, b64(boxKp.secretKey.asBytes))
            .putString(PREF_BOX_PUB, b64(boxKp.publicKey.asBytes))
            .apply()
        Logger.d("CryptoManager", "fresh keypairs generated")
    }

    fun identityPublicKey(): ByteArray {
        return unb64(requireNotNull(prefs.getString(PREF_IDENTITY_PUB, null)))
    }

    fun boxPublicKey(): ByteArray {
        return unb64(requireNotNull(prefs.getString(PREF_BOX_PUB, null)))
    }

    private fun boxPrivateKey(): ByteArray =
        unb64(requireNotNull(prefs.getString(PREF_BOX_PRIV, null)))

    // ------------------------------------------------------------------
    // Auth: sign server challenge with Ed25519 identity key
    // ------------------------------------------------------------------

    fun signChallenge(challenge: ByteArray): ByteArray {
        val priv = unb64(requireNotNull(prefs.getString(PREF_IDENTITY_PRIV, null)))
        // Reconstruct full secret key from seed
        val pub = ByteArray(Sign.ED25519_PUBLICKEYBYTES)
        val fullPriv = ByteArray(Sign.ED25519_SECRETKEYBYTES)
        sodium.cryptoSignSeedKeypair(pub, fullPriv, priv)
        val sig = ByteArray(Sign.ED25519_BYTES)
        check(sodium.cryptoSignDetached(sig, challenge, challenge.size, fullPriv))
        return sig
    }

    // ------------------------------------------------------------------
    // 1-on-1: crypto_box (X25519 + XSalsa20-Poly1305, anonymous nonce)
    // ------------------------------------------------------------------

    data class Sealed(val nonceB64: String, val cipherB64: String)

    fun boxEncrypt(peerPubKey: ByteArray, plaintext: ByteArray): Sealed {
        val nonce = ByteArray(Box.NONCEBYTES).also { random.nextBytes(it) }
        val cipher = ByteArray(plaintext.size + Box.MACBYTES)
        check(sodium.cryptoBoxEasy(cipher, plaintext, plaintext.size.toLong(),
                                   nonce, peerPubKey, boxPrivateKey()))
        return Sealed(b64(nonce), b64(cipher))
    }

    fun boxDecrypt(peerPubKey: ByteArray, nonceB64: String,
                   cipherB64: String): ByteArray {
        val nonce = unb64(nonceB64)
        val cipher = unb64(cipherB64)
        require(nonce.size == Box.NONCEBYTES) { "bad nonce" }
        val plain = ByteArray(cipher.size - Box.MACBYTES)
        check(sodium.cryptoBoxOpenEasy(plain, cipher, cipher.size.toLong(),
                                       nonce, peerPubKey, boxPrivateKey())) {
            "decrypt failed: wrong key or tampered ciphertext"
        }
        return plain
    }

    // ------------------------------------------------------------------
    // Groups + files: crypto_secretbox (XSalsa20-Poly1305, shared key)
    // ------------------------------------------------------------------

    fun secretEncrypt(key: ByteArray, plaintext: ByteArray): Sealed {
        require(key.size == SecretBox.KEYBYTES) { "bad key length" }
        val nonce = ByteArray(SecretBox.NONCEBYTES).also { random.nextBytes(it) }
        val cipher = ByteArray(plaintext.size + SecretBox.MACBYTES)
        check(sodium.cryptoSecretBoxEasy(cipher, plaintext,
                                         plaintext.size.toLong(), nonce, key))
        return Sealed(b64(nonce), b64(cipher))
    }

    fun secretDecrypt(key: ByteArray, nonceB64: String,
                      cipherB64: String): ByteArray {
        require(key.size == SecretBox.KEYBYTES) { "bad key length" }
        val nonce = unb64(nonceB64)
        val cipher = unb64(cipherB64)
        return secretDecryptRaw(key, nonce, cipher)
    }

    /** Raw-bytes variant (avoids base64 round-trip on large files). */
    fun secretDecryptRaw(key: ByteArray, nonce: ByteArray,
                         cipher: ByteArray): ByteArray {
        require(key.size == SecretBox.KEYBYTES) { "bad key length" }
        require(nonce.size == SecretBox.NONCEBYTES) { "bad nonce" }
        val plain = ByteArray(cipher.size - SecretBox.MACBYTES)
        check(sodium.cryptoSecretBoxOpenEasy(plain, cipher,
                                             cipher.size.toLong(), nonce, key)) {
            "decrypt failed"
        }
        return plain
    }

    fun randomKey(): ByteArray =
        ByteArray(SecretBox.KEYBYTES).also { random.nextBytes(it) }

    /** Wipe keys (logout). Messages already sent stay encrypted forever. */
    fun wipeKeys() {
        prefs.edit().remove(PREF_IDENTITY_PRIV).remove(PREF_IDENTITY_PUB)
            .remove(PREF_BOX_PRIV).remove(PREF_BOX_PUB).apply()
    }
}
