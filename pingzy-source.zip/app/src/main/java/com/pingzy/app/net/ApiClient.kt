package com.pingzy.app.net

import com.pingzy.app.BuildConfig
import com.pingzy.app.util.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * HTTP client: OTP endpoints + encrypted file upload/download.
 * Uploads are client-side-encrypted blobs; server can't read them.
 * Chunked/resumable upload: Phase 2 (see ARCHITECTURE.md).
 */
class ApiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val base = BuildConfig.SERVER_HTTP_URL

    suspend fun otpRequest(email: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url("$base/otp/request").post(body).build()
        http.newCall(req).execute().use { it.isSuccessful }
    }

    /** Returns verification token or null. */
    suspend fun otpVerify(email: String, code: String): String? =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("email", email).put("code", code)
                .toString().toRequestBody("application/json".toMediaType())
            val req = Request.Builder().url("$base/otp/verify").post(body).build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return@withContext null
                JSONObject(r.body!!.string()).optString("verification_token")
                    .takeIf { it.isNotEmpty() }
            }
        }

    data class UploadResult(val fileId: String, val size: Long)

    /** Upload an already-encrypted blob. onProgress: 0..100. */
    suspend fun uploadFile(
        encryptedFile: File, filename: String, mime: String,
        uploadToken: String, onProgress: (Int) -> Unit = {}
    ): UploadResult = withContext(Dispatchers.IO) {
        val total = encryptedFile.length()
        val counting = object : RequestBody() {
            override fun contentType() = mime.toMediaType()
            override fun contentLength() = total
            override fun writeTo(sink: okio.BufferedSink) {
                encryptedFile.inputStream().use { ins ->
                    val buf = ByteArray(65536)
                    var sent = 0L; var n: Int
                    while (ins.read(buf).also { n = it } != -1) {
                        sink.write(buf, 0, n); sent += n
                        onProgress(((sent * 100) / total).toInt())
                    }
                }
            }
        }
        val form = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", filename, counting).build()
        val req = Request.Builder().url("$base/files").post(form)
            .header("X-Upload-Token", uploadToken).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("upload ${r.code}")
            val j = JSONObject(r.body!!.string())
            UploadResult(j.getString("file_id"), j.getLong("size"))
        }.also { Logger.i("ApiClient", "uploaded $total bytes") }
    }

    suspend fun downloadFile(fileId: String, dest: File,
                             onProgress: (Int) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            val req = Request.Builder().url("$base/files/$fileId").get().build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw RuntimeException("dl ${r.code}")
                val body = r.body!!
                val total = body.contentLength()
                body.byteStream().use { ins ->
                    dest.outputStream().use { out ->
                        val buf = ByteArray(65536)
                        var got = 0L; var n: Int
                        while (ins.read(buf).also { n = it } != -1) {
                            out.write(buf, 0, n); got += n
                            if (total > 0) onProgress(((got * 100) / total).toInt())
                        }
                    }
                }
            }
        }
}
