package com.pingzy.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.pingzy.app.R
import com.pingzy.app.PingzyApp

/** Minimal settings: identity info, pending outbox, logout (wipes keys). */
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val app = application as PingzyApp
        setContentView(R.layout.activity_settings)
        title = "Settings"
        val info = findViewById<TextView>(R.id.settings_info)
        val pub = try {
            com.pingzy.app.crypto.CryptoManager
                .b64(app.crypto.boxPublicKey()).take(24) + "..."
        } catch (_: Exception) { "?" }
        info.text = "Logged in as: ${app.session.username}\n" +
                "Public key: $pub\n\n" +
                "Privacy: private keys never leave this phone.\n" +
                "The server only relays encrypted blobs."

        findViewById<Button>(R.id.btn_logout).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Log out?")
                .setMessage("This wipes your private keys from this phone. " +
                        "You'll need to register again. Messages already " +
                        "sent stay encrypted.")
                .setPositiveButton("Log out") { _, _ ->
                    app.chatClient.disconnect()
                    app.session.logout(this)
                    startActivity(Intent(this, RegisterActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or
                                Intent.FLAG_ACTIVITY_NEW_TASK))
                    finish()
                }
                .setNegativeButton("Cancel", null).show()
        }
    }
}
