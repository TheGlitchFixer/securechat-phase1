package com.pingzy.app

import android.app.Application
import android.content.Context
import com.pingzy.app.crypto.CryptoManager
import com.pingzy.app.data.AppDatabase
import com.pingzy.app.net.ApiClient
import com.pingzy.app.net.ChatClient
import com.pingzy.app.net.MessageQueue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class PingzyApp : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var crypto: CryptoManager
        private set
    lateinit var db: AppDatabase
        private set
    lateinit var chatClient: ChatClient
        private set
    lateinit var api: ApiClient
        private set
    lateinit var queue: MessageQueue
        private set
    lateinit var session: Session
        private set
    lateinit var inbox: InboxHandler
        private set

    override fun onCreate() {
        super.onCreate()
        crypto = CryptoManager.get(this)
        db = AppDatabase.get(this)
        api = ApiClient()
        chatClient = ChatClient(crypto, appScope)
        queue = MessageQueue(db, chatClient, appScope)
        session = Session(this)
        inbox = InboxHandler(this)
        chatClient.listener = inbox
    }
}

/** Logged-in identity (username). Private keys stay in CryptoManager. */
class Session(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("session", Context.MODE_PRIVATE)
    var username: String?
        get() = p.getString("username", null)
        set(v) { p.edit().putString("username", v).apply() }
    val loggedIn: Boolean get() = username != null && CryptoManager
        .get(ctx).hasKeys()
    fun logout(ctx: Context) {
        CryptoManager.get(ctx).wipeKeys()
        p.edit().clear().apply()
    }
}
