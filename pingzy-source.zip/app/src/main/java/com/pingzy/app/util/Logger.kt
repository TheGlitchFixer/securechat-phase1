package com.pingzy.app.util

import android.util.Log

/**
 * App-wide logger with a HARD RULE: never log sensitive data.
 *
 * Forbidden in logs: private keys, public keys, plaintext message bodies,
 * ciphertext, nonces, OTP codes, file contents, auth tokens.
 * Allowed: usernames, message IDs, file sizes, connection states, timings.
 *
 * R8 strips ALL logging in release builds (see proguard-rules.pro).
 * e()/w() remain in debug builds but must still never carry sensitive values.
 */
object Logger {
    private const val TAG_PREFIX = "Pingzy."

    fun d(tag: String, msg: String) = Log.d(TAG_PREFIX + tag, msg)
    fun v(tag: String, msg: String) = Log.v(TAG_PREFIX + tag, msg)
    fun i(tag: String, msg: String) = Log.i(TAG_PREFIX + tag, msg)
    fun w(tag: String, msg: String) = Log.w(TAG_PREFIX + tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) {
        if (t != null) Log.e(TAG_PREFIX + tag, msg, t)
        else Log.e(TAG_PREFIX + tag, msg)
    }

    /**
     * Redact a value for safe logging. Use for anything user-supplied
     * that might be sensitive.
     */
    fun redact(value: String?, keep: Int = 0): String {
        if (value.isNullOrEmpty()) return "<empty>"
        return if (keep > 0 && value.length > keep) {
            value.take(keep) + "...<redacted>"
        } else {
            "<redacted>"
        }
    }
}
