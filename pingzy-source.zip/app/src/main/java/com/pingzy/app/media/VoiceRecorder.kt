package com.pingzy.app.media

import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import com.pingzy.app.util.Logger
import java.io.File

/**
 * Voice messages. Codec: Opus @ ~12kbps on API 26+ (tiny files, ideal for
 * poor networks); AAC @ 24kbps fallback on API 21-25. Output is encrypted
 * by the caller before upload — this class only handles raw audio.
 */
class VoiceRecorder {

    private var recorder: MediaRecorder? = null
    private var outFile: File? = null

    val isOpus: Boolean = Build.VERSION.SDK_INT >= 26

    @Suppress("DEPRECATION")
    fun start(cacheDir: File): File {
        stop(cancel = true)
        outFile = File(cacheDir,
            "voice_${System.currentTimeMillis()}.${if (isOpus) "opus" else "m4a"}")
        recorder = if (Build.VERSION.SDK_INT >= 31) {
            MediaRecorder(cacheDir)
        } else {
            MediaRecorder()
        }.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(if (isOpus) MediaRecorder.OutputFormat.OGG
                            else MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(if (isOpus) MediaRecorder.AudioEncoder.OPUS
                            else MediaRecorder.AudioEncoder.AAC)
            // Low-bandwidth: Opus ~12kbps, AAC ~24kbps mono
            setAudioEncodingBitRate(if (isOpus) 12_000 else 24_000)
            setAudioSamplingRate(if (isOpus) 16000 else 22050)
            setAudioChannels(1)
            setOutputFile(outFile!!.absolutePath)
            prepare(); start()
        }
        Logger.d("VoiceRecorder", "recording (${if (isOpus) "opus" else "aac"})")
        return outFile!!
    }

    /** Returns the recorded file, or null if cancelled/failed. */
    fun stop(cancel: Boolean = false): File? {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        val f = outFile; outFile = null
        if (cancel) { f?.delete(); return null }
        return f?.takeIf { it.exists() && it.length() > 0 }
    }

    val isRecording: Boolean get() = recorder != null
}

/** Simple voice-message playback. */
class VoicePlayer {
    private var player: MediaPlayer? = null
    var onDone: (() -> Unit)? = null

    fun play(file: File) {
        stop()
        player = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            setOnCompletionListener { onDone?.invoke() }
            prepare(); start()
        }
    }

    fun stop() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    val isPlaying: Boolean get() = try { player?.isPlaying == true }
        catch (_: Exception) { false }
}
