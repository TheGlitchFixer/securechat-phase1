package com.pingzy.app

import com.pingzy.app.crypto.CryptoManager
import com.pingzy.app.data.GroupEntity
import com.pingzy.app.data.MessageEntity
import com.pingzy.app.net.ChatClient
import com.pingzy.app.util.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Incoming message pipeline: decrypt E2E -> store locally -> ack -> notify UI.
 * Auto-processes group-key distribution messages (kind="group_key").
 *
 * Correctness notes:
 *  - Every incoming frame is acked by msg_id; the server keeps unacked
 *    messages queued, so a crash never loses mail (at-least-once).
 *  - Local inserts use INSERT OR IGNORE on msg_id: duplicates from
 *    live-push + sync overlap are harmless.
 *  - Decryption failures are logged (no key material) and skipped —
 *    one bad message never breaks the stream.
 */
class InboxHandler(private val app: PingzyApp) : ChatClient.Listener {

    var onNewMessage: ((chatId: String) -> Unit)? = null
    var onConnected: ((Boolean) -> Unit)? = null
    private val scope: CoroutineScope get() = app.appScope

    override fun onConnectionChange(connected: Boolean) {
        Logger.i("Inbox", "connected=$connected")
        onConnected?.invoke(connected)
        if (connected) scope.launch(Dispatchers.IO) {
            // LOW-BANDWIDTH: flush outbox first, then pull server queue.
            app.queue.pump()
            try {
                val frames = app.chatClient.sync()
                val ids = mutableListOf<Long>()
                for (f in frames) {
                    try {
                        handleOne(f)
                        ids.add(f.getLong("msg_id"))
                    } catch (e: Exception) {
                        Logger.w("Inbox", "sync frame failed: ${e.message}")
                    }
                }
                if (ids.isNotEmpty()) ack(ids)
            } catch (e: Exception) {
                Logger.w("Inbox", "sync failed: ${e.message}")
            }
        }
    }

    override fun onMessage(msg: JSONObject) {
        // Live push (we're online). Handle on IO; ack right away.
        scope.launch(Dispatchers.IO) {
            try {
                handleOne(msg)
                ack(listOf(msg.getLong("msg_id")))
            } catch (e: Exception) {
                Logger.w("Inbox", "live message failed: ${e.message}")
            }
        }
    }

    private fun ack(ids: List<Long>) {
        app.chatClient.sendRaw(JSONObject()
            .put("type", "ack")
            .put("msg_ids", JSONArray(ids)))
    }

    private suspend fun handleOne(m: JSONObject) {
        val crypto = app.crypto
        val kind = m.getString("kind")          // dm | group
        val from = m.getString("from")
        val msgId = m.getLong("msg_id")
        val ts = (m.optDouble("ts", 0.0) * 1000).toLong()

        val plain = JSONObject(String(if (kind == "dm") {
            val contact = app.db.contacts().get(from)
                ?: throw RuntimeException("message from unknown contact")
            crypto.boxDecrypt(CryptoManager.unb64(contact.boxPubKeyB64),
                m.getString("nonce"), m.getString("ciphertext"))
        } else {
            val g = app.db.groups().get(m.getLong("group_id"))
                ?: throw RuntimeException("message for unknown group")
            crypto.secretDecrypt(CryptoManager.unb64(g.groupKeyB64),
                m.getString("nonce"), m.getString("ciphertext"))
        }))

        // Group key distribution (sent as ordinary E2E dm by group admin)
        if (plain.optString("kind") == "group_key") {
            val gid = plain.getLong("group_id")
            val existing = app.db.groups().get(gid)
            app.db.groups().upsert(GroupEntity(
                groupId = gid,
                name = existing?.name ?: m.optString("group_name", "Group"),
                membersJson = existing?.membersJson ?: "[]",
                groupKeyB64 = plain.getString("group_key")))
            Logger.i("Inbox", "stored group key")
            return
        }

        val chatId = if (kind == "dm") from else "group:${m.getLong("group_id")}"
        app.db.messages().insert(MessageEntity(
            msgId = msgId, chatId = chatId, kind = kind, sender = from,
            groupId = if (kind == "group") m.getLong("group_id") else null,
            groupName = m.optString("group_name", null),
            msgType = m.optString("msg_type", "text"),
            body = plain.toString(), ts = ts, outgoing = false))
        onNewMessage?.invoke(chatId)
    }
}
