package com.pingzy.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A chat message as stored LOCALLY after decryption.
 * The server never sees these fields — it only stores opaque blobs.
 */
@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val msgId: Long,          // server msg_id (dedupe key)
    val chatId: String,                   // username (dm) or "group:<id>"
    val kind: String,                     // "dm" | "group"
    val sender: String,
    val groupId: Long? = null,
    val groupName: String? = null,
    val msgType: String,                  // text | file | voice
    val body: String,                     // plaintext text OR json metadata
    val ts: Long,                         // epoch millis
    val outgoing: Boolean                 // sent by me?
)

/**
 * Outbox: messages queued locally when offline / on poor networks.
 * Sent in FIFO order with exponential backoff (see MessageQueue).
 * The plaintext here is ALREADY encrypted (ciphertext only) — even the
 * local queue never holds plaintext longer than needed for display.
 */
@Entity(tableName = "outbox")
data class OutboxEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: String,
    val kind: String,                     // "dm" | "group"
    val recipient: String,                // username or group_id as string
    val nonceB64: String,                 // base64 (NOT sensitive alone)
    val cipherB64: String,                // E2E ciphertext blob
    val msgType: String,
    val attempts: Int = 0,
    val nextTryAt: Long = 0,              // epoch millis
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val username: String,
    val boxPubKeyB64: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "groups")
data class GroupEntity(
    @PrimaryKey val groupId: Long,
    val name: String,
    val membersJson: String,              // JSON array of usernames
    val groupKeyB64: String               // secretbox key (local only!)
)
